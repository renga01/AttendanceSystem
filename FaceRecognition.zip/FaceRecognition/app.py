from flask import Flask, render_template, request, redirect, url_for
import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime

app = Flask(__name__)

# Function to create a directory if it does not exist
def create_directory(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

# Function to capture images of students for training
def capture_images():
    create_directory('images')

    # Load the Haar Cascade face classifier
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    # Start capturing video from the webcam
    cap = cv2.VideoCapture(0)

    # Initialize variables
    student_name = request.form.get('student_name')
    image_count = 0

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()

        # Convert the frame to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect faces in the frame
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

        for (x, y, w, h) in faces:
            # Draw a rectangle around the detected face
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

            # Save the detected face
            image_count += 1
            cv2.imwrite(f'images/{student_name}_{image_count}.jpg', gray[y:y+h, x:x+w])

        # Display the frame
        cv2.imshow('Capture Images', frame)

        # Hit 'q' on the keyboard to quit capturing
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        # Limit the number of images captured
        if image_count >= 50:
            break

    # Release the video capture
    cap.release()
    cv2.destroyAllWindows()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/capture', methods=['POST'])
def capture():
    capture_images()
    return redirect(url_for('index'))

@app.route('/start_attendance', methods=['POST'])

@app.route('/start_attendance', methods=['POST'])
def start_attendance():
    # Load known faces and encode them
    known_face_encodings, known_face_names = load_images_and_encode_faces()

    # Initialize some variables
    face_locations = []
    face_encodings = []
    face_names = []
    process_this_frame = True

    # Open webcam
    cap = cv2.VideoCapture(0)

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()

        if not ret:
            # If frame is not captured properly, continue to the next iteration
            continue

        # Resize frame to speed up face recognition
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

        # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
        rgb_small_frame = np.ascontiguousarray(small_frame[:, :, ::-1])

        # Only process every other frame of video to save time
        if process_this_frame:
            # Find all the faces and face encodings in the current frame of video
            face_locations = face_recognition.face_locations(rgb_small_frame)
            face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

            face_names = []
            for face_encoding in face_encodings:
                # Compare face encoding with known face encodings
                # Adjust the tolerance level for better results (default is 0.6)
                matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.4)
                name = "Unknown"

                # If a match is found, use the name of the known face
                if True in matches:
                    matched_index = matches.index(True)
                    name = known_face_names[matched_index]

                face_names.append(name)

        process_this_frame = not process_this_frame

        # Display the results
        for (top, right, bottom, left), name in zip(face_locations, face_names):
            # Scale back up face locations since the frame we detected in was scaled to 1/4 size
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            # Draw a rectangle around the face
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

            # Draw a label with a name below the face
            cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

            # Mark attendance if the name is not Unknown
            if name != "Unknown":
                mark_attendance(name)

        # Display the resulting image
        cv2.imshow('Video', frame)

        # Hit 'q' on the keyboard to quit!
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release handle to the webcam
    cap.release()
    cv2.destroyAllWindows()
    return redirect(url_for('index'))


def mark_attendance(name):
    with open('attendance.csv', 'a') as f:
        now = datetime.now()
        dt_string = now.strftime("%Y-%m-%d %H:%M:%S")
        f.write(f'{name},{dt_string}\n')

def load_images_and_encode_faces():
    known_face_encodings = []
    known_face_names = []
    path = 'images'
    images = []
    myList = os.listdir(path)
    for cl in myList:
        curImg = cv2.imread(f'{path}/{cl}')
        images.append(curImg)
        known_face_names.append(os.path.splitext(cl)[0])
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)
        if len(encode) > 0:
            encode = encode[0]
            known_face_encodings.append(encode)
    return known_face_encodings, known_face_names

if __name__ == '__main__':
    app.run(debug=True)
